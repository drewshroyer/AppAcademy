class Array
  # Write an `Array#my_inject` method. If my_inject receives no argument, then
  # use the first element of the array as the default accumulator.
  # **Do NOT use the built-in `Array#inject` or `Array#reduce` methods in your 
  # implementation.**

  def my_inject(accumulator = nil, &prc)
    


  end

end

# self.each do |ele|
#   if accumulator == nil 
#     accumulator = self[0]
#   accumulator += prc.call(ele)
#   else
#     accumulator += prc.call(ele)
#   end
# end
# accumulator
# end

# Define a method `primes(num)` that returns an array of the first "num" primes.
# You may wish to use an `is_prime?` helper method.

def primes(num)is_prime?(num)
  array = []
  i = 0 
  while array.length < num 
    if is_prime?(i)
      array << i
    end
    i += 1
  end
array
end

def is_prime?(num)
  if num < 2
    return false 
  end
(2...num).each do |factor|
  if num % factor == 0
    return false
  end
end
true
end

# Write a recursive method that returns the first "num" factorial numbers.
# Note that the 1st factorial number is 0!, which equals 1. The 2nd factorial
# is 1!, the 3rd factorial is 2!, etc.

def factorials_rec(num)
  return [1] if num == 1 
  return [1, 1] if num == 2

 factorials_rec(num - 1).concat([(num - 1) * factorial(num - 2)])
end

def factorial(num)
  return 1 if num == 0 
  return 1 if num == 1 
  num * factorial(num - 1)
end

class Array
  # Write an `Array#dups` method that will return a hash containing the indices 
  # of all duplicate elements. The keys are the duplicate elements; the values 
  # are arrays of their indices in ascending order, e.g.
  # [1, 3, 4, 3, 0, 3, 0].dups => { 3 => [1, 3, 5], 0 => [4, 6] }

  def dups
    hash = Hash.new(0)
    self.each_with_index do |ele, i|
      self.each_with_index do |ele2, i2|
        if ele == ele2 && i != i2 
          if hash.has_key?(ele)
              hash[ele] << i2
          else
            hash[ele] = [i2]
          end
        end
      end
    end
    hash.each do |k, v|
      hash[k] = v.sort.uniq
    end
    hash
  end
end

class String
  # Write a `String#symmetric_substrings` method that returns an array of 
  # substrings that are palindromes, e.g. "cool".symmetric_substrings => ["oo"]
  # Only include substrings of length > 1.

  def symmetric_substrings
    substrings = []
    i = 0 
    while i < self.length
      x = 0
      while x < self.length
        new_str = ""
        new_str += self[i..x]
        substrings << new_str
      x += 1
      end
    i += 1
    end
    remove_dups = substrings.uniq
    answer = []
    remove_dups.each do |ele|
      if palindrome?(ele) && ele.length > 1
        answer << ele
      end
    end
    answer
  end

  def palindrome?(str)
    str == str.reverse
  end

end

class Array
  # Write an `Array#merge_sort` method; it should not modify the original array.
  # **Do NOT use the built in `Array#sort` or `Array#sort_by` methods in your 
  # implementation.**
  
  def merge_sort(&prc)
    return [] if self.empty?
    return self if self.length == 1
    
  
  end

  private
  def self.merge(left, right, &prc)


  end


end
