


def my_uniq(arr)
    
end

class Array

    def two_sum
    
    end

end

def my_transpose(matrix)


end

def stock_picker(arr)

end

# TOWERS OF HANOI 



