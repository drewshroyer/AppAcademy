require 'rspec'
require 'practice_tdd'

describe '#my_uniq' do 
    it "remove dup from an arr" do 
        expect([1, 2, 1, 3, 3].my_uniq).to eq([1, 2, 3])
    end

    it "should returns the unique elements in the order in which they first appeared" do 
        expect([3, 1, 2, 1, 3, 3, 1, 2, 3].my_uniq).to eq([3, 1, 2])
    end
end




# gem install rspec      # for rspec-core, rspec-expectations, rspec-mocks
# gem install rspec-core # for rspec-core only
# rspec --help